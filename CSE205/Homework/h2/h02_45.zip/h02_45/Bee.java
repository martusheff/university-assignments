public class Bee extends Insect {

    @Override
    public void makeSound() { System.out.println("Buzz"); }
}
