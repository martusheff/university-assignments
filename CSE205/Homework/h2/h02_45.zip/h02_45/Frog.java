public class Frog extends Amphibian {
    @Override
    public void makeSound() { System.out.println("Ribbet");
    }
}
