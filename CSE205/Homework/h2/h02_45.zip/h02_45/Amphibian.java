public abstract class Amphibian implements MakesSound {
}
